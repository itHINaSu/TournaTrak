# TournaTrak — Mobile Bracket Redesign Spec

## Goal

Replace the current mobile bracket (two separate left/right snap-scroll sections stacked vertically) with a single continuous vertical scroll that flows left bracket → right bracket → championship, ESPN Tournament Challenge style.

---

## Desired Behavior

### Scroll direction
- **Vertical** primary scroll — the user scrolls down through the bracket
- No horizontal scrolling in the new layout
- The full bracket (both sides + championship) is one continuous vertical document

### Card sizing
- Each round column is **1.25 cards wide** — the current round fills most of the screen, and the leading edge of the next round is visible as a peek
- This "peek" signals to the user that there is more to scroll to

### Snap behavior
- Vertical snap — as the user scrolls, the view snaps so a round column aligns cleanly to the left edge
- Snapping should feel like flicking between rounds, not like fighting the scroll
- `scroll-snap-type: y mandatory` on the outer container
- Each round column gets `scroll-snap-align: start`

### Connector lines
- As rounds progress (R1 → R2 → QF → SF), the vertical gap between games naturally narrows (R2 midpoints align to R1 pair midpoints, etc.)
- Connector lines should converge accordingly — they do not need to be horizontal; vertical or diagonal lines between rounds are acceptable
- The current SVG connector approach used on desktop may not translate directly; consider a simpler approach for mobile (e.g. thin vertical lines between cards)

### Championship at the bottom
- Championship card appears at the bottom of the scroll, after both SF cards, without starting a new row or section
- No `mobile-bracket-divider` between sides — the flow is seamless

### Layout order (top to bottom)
1. Left bracket: R1 (slots 2–4) → R2 → QF → SF
2. Right bracket: R1 (slots 2–4) → R2 → QF → SF
3. Championship

Or alternatively, interleaved by round if that produces better connector alignment (ask at implementation time).

---

## Current Implementation (what to replace)

In `index.html`, the function `renderMobileBracket(root, dims)` handles all mobile rendering.

### Current structure
```
root
└── div (98vw, margin auto)
    ├── mobileSide('L', label)       ← snap-scroll horizontal, 49vw columns
    ├── .mobile-bracket-divider
    ├── mobileSide('R', label)       ← snap-scroll horizontal, 49vw columns
    └── champBar
```

### Current `mobileSide` internals
- Outer container: `display:flex; overflow-x:scroll; scroll-snap-type:x mandatory`
- Each round column: `flex:0 0 49vw; scroll-snap-align:start; scroll-snap-stop:always`
- Cards: `position:absolute` inside the column, positioned by `slotTopVh()`
- Column height: `totalVh = slotVh * 8` (8 virtual slots)

### CSS classes involved
- `.mobile-bracket-wrap` — currently unused by JS (JS builds inline styles), but exists in CSS
- `.mobile-bracket-section` — same
- `.mobile-bracket-label` — round label styling
- `.mobile-bracket-divider` — horizontal rule between left/right

---

## Sizing constants (from `index.html`)

```javascript
var CARD_RATIO  = 0.82;   // card height as fraction of slot height
var CARD_ASPECT = 2.6;    // card width:height ratio
```

### Slot position math (currently used, may need adaptation)
```javascript
function slotTopVh(round, slot, slotVh) {
  if (round === 'R1')    return (slot - 1) * slotVh;
  if (round === 'R2')    return ((slot - 1) * 2 + 0.5) * slotVh;
  if (round === 'QF')    return ((slot - 1) * 4 + 1.5) * slotVh;
  if (round === 'SF')    return 3.5 * slotVh;
  if (round === 'CHAMP') return 3.5 * slotVh;
}
```
R2 slot midpoints land exactly halfway between their two R1 source slot midpoints. This is guaranteed by the formula and is what makes connector lines work correctly.

---

## Key data functions available (from `bracket-data.js`)

```javascript
buildSideColumns(side)     // returns [{round, games:[{gid, slot}]}] for 'L' or 'R'
GAMES[sid]                 // {label, round, side, num, time, t1, t2}
resolveSlot(slot, results) // returns team name or null
smartLabel(slot, results)  // returns best display label
formatTime(t)              // 'YYYY-MM-DDTHH:MM' → 'm/d Fullday H:MM AM'
gameLabel(sid)             // GAMES[sid].label or sid
```

---

## What NOT to change

- `renderDesktopBracket()` — desktop layout is working correctly, do not touch
- `getDims()` — sizing logic is shared; mobile branch may need its own sizing
- `bracket-data.js` — no changes needed
- `bracket.css` — the implementer should read the current file carefully before adding mobile-specific rules; note that several mobile CSS classes exist but are not currently used by the JS

---

## Open questions for the implementer

1. Should the two bracket sides be interleaved by round (L-R1, R-R1, L-R2, R-R2...) or sequential (all of L, then all of R)? Sequential is simpler; interleaved may feel more natural for a double-elimination bracket.

2. Should connector lines be drawn between rounds in the vertical layout? If yes, what style — thin vertical lines, diagonal SVG, or dots/arrows?

3. The "peek" of 1.25 cards wide: should this be the peek of the next **round** (horizontal peek within a side), or the next **game** (vertical peek of the card below)?

4. Championship: inline at the bottom of the scroll, or a fixed bar that appears once both SF games are scrolled past?
