// bracket-data.js
// Primary key: slot ID  e.g. 'R1.L.1', 'R2.R.3', 'QF.L.1', 'SF.R.1', 'CHAMP.1'
// Slot ID format: {ROUND}.{SIDE}.{NUM}  where SIDE = L|R, NUM = 1-based sequential
// Team source: { type:'winner'|'loser', slot:'R1.L.1' }  or  { type:'fixed', team:'...' }

// ── Slot definition ────────────────────────────────────────
// All possible slots per round/side (including empty ones)
const SLOT_DEFS = {
  R1: { L: [1,2,3,4,5,6,7,8], R: [1,2,3,4,5,6,7,8] },
  R2: { L: [1,2,3,4],         R: [1,2,3,4] },
  QF: { L: [1,2],             R: [1,2] },
  SF: { L: [1],               R: [1] },
  CHAMP: { C: [1] }
};

// All valid slot IDs
function allSlotIds() {
  const ids = [];
  for (const [round, sides] of Object.entries(SLOT_DEFS)) {
    for (const [side, nums] of Object.entries(sides)) {
      for (const n of nums) {
        ids.push(round + '.' + side + '.' + n);
      }
    }
  }
  return ids;
}

// Parse a slot ID into parts
function parseSlotId(sid) {
  const parts = sid.split('.');
  return { round: parts[0], side: parts[1], num: parseInt(parts[2]) };
}

// ── GAMES — keyed by slot ID ───────────────────────────────
// label: display name shown on cards and in "Winner of..." refs (editable)
// Empty slots are not present — only occupied slots
const GAMES = {
  // ── Round 1 Left ──
  'R1.L.1': { label:'G1',  round:'R1', side:'L', num:1, time:'Sun 11:30',
    t1:{ type:'fixed', team:'High Point Roofing' },
    t2:{ type:'fixed', team:'Dollys' } },
  'R1.L.3': { label:'G3',  round:'R1', side:'L', num:3, time:'Sun 12:20',
    t1:{ type:'fixed', team:'Brew Crew' },
    t2:{ type:'fixed', team:'Electric Motor Supply' } },
  'R1.L.5': { label:'G5',  round:'R1', side:'L', num:5, time:'Sun 1:10',
    t1:{ type:'fixed', team:'Hoegeymeyer Seeds/Feld Fire' },
    t2:{ type:'fixed', team:'Kerps/Budweiser' } },

  // ── Round 1 Right ──
  'R1.R.1': { label:'G2',  round:'R1', side:'R', num:1, time:'Sun 2:00',
    t1:{ type:'fixed', team:'Shreck Bin Co Red' },
    t2:{ type:'fixed', team:'WP Trucking' } },
  'R1.R.2': { label:'G4',  round:'R1', side:'R', num:2, time:'Sun 2:50',
    t1:{ type:'fixed', team:'Michaels Shoes' },
    t2:{ type:'fixed', team:'Wittrock Electric/Weitl Auto' } },
  'R1.R.3': { label:'G6',  round:'R1', side:'R', num:3, time:'Sun 3:30',
    t1:{ type:'fixed', team:'Templeton Distillery' },
    t2:{ type:'fixed', team:'Tropics' } },

  // ── Round 2 Left ──
  'R2.L.1': { label:'G7',  round:'R2', side:'L', num:1, time:'Mon 6:00',
    t1:{ type:'fixed',  team:'Wasted Grain' },
    t2:{ type:'loser',  slot:'R1.L.5' } },
  'R2.L.2': { label:'G9',  round:'R2', side:'L', num:2, time:'Mon 7:40',
    t1:{ type:'winner', slot:'R1.L.1' },
    t2:{ type:'winner', slot:'R1.L.3' } },
  'R2.L.3': { label:'G11', round:'R2', side:'L', num:3, time:'Wed 6:50',
    t1:{ type:'winner', slot:'R1.L.5' },
    t2:{ type:'loser',  slot:'R1.L.1' } },
  'R2.L.4': { label:'G13', round:'R2', side:'L', num:4, time:'Wed 6:00',
    t1:{ type:'loser',  slot:'R1.L.3' },
    t2:{ type:'loser',  slot:'R2.R.1' } },

  // ── Round 2 Right ──
  'R2.R.1': { label:'G8',  round:'R2', side:'R', num:1, time:'Mon 6:50',
    t1:{ type:'fixed',  team:'Coors Light' },
    t2:{ type:'loser',  slot:'R1.R.3' } },
  'R2.R.2': { label:'G10', round:'R2', side:'R', num:2, time:'Mon 9:20',
    t1:{ type:'winner', slot:'R1.R.1' },
    t2:{ type:'winner', slot:'R1.R.2' } },
  'R2.R.3': { label:'G12', round:'R2', side:'R', num:3, time:'Mon 8:30',
    t1:{ type:'winner', slot:'R1.R.3' },
    t2:{ type:'loser',  slot:'R1.R.1' } },
  'R2.R.4': { label:'G14', round:'R2', side:'R', num:4, time:'Wed 7:40',
    t1:{ type:'loser',  slot:'R1.R.2' },
    t2:{ type:'loser',  slot:'R2.L.1' } },

  // ── Quarter Finals Left ──
  'QF.L.1': { label:'G15', round:'QF', side:'L', num:1, time:'Wed 9:20',
    t1:{ type:'winner', slot:'R2.L.1' },
    t2:{ type:'winner', slot:'R2.L.2' } },
  'QF.L.2': { label:'G17', round:'QF', side:'L', num:2, time:'Fri 6:00',
    t1:{ type:'winner', slot:'R2.L.3' },
    t2:{ type:'winner', slot:'R2.L.4' } },

  // ── Quarter Finals Right ──
  'QF.R.1': { label:'G16', round:'QF', side:'R', num:1, time:'Wed 8:30',
    t1:{ type:'winner', slot:'R2.R.1' },
    t2:{ type:'winner', slot:'R2.R.2' } },
  'QF.R.2': { label:'G18', round:'QF', side:'R', num:2, time:'Fri 6:50',
    t1:{ type:'winner', slot:'R2.R.3' },
    t2:{ type:'winner', slot:'R2.R.4' } },

  // ── Semi Finals ──
  'SF.L.1': { label:'G19', round:'SF', side:'L', num:1, time:'Fri 7:40',
    t1:{ type:'winner', slot:'QF.L.1' },
    t2:{ type:'winner', slot:'QF.L.2' } },
  'SF.R.1': { label:'G20', round:'SF', side:'R', num:1, time:'Fri 8:30',
    t1:{ type:'winner', slot:'QF.R.1' },
    t2:{ type:'winner', slot:'QF.R.2' } },

  // ── Championship ──
  'CHAMP.C.1': { label:'G21', round:'CHAMP', side:'C', num:1, time:'Fri 9:20',
    t1:{ type:'winner', slot:'SF.L.1' },
    t2:{ type:'winner', slot:'SF.R.1' } },
};

const ROUND_ORDER  = ['R1','R2','QF','SF','CHAMP'];
const ROUND_LABELS = {
  R1:'Round 1', R2:'Round 2', QF:'Quarter Finals', SF:'Semi Finals', CHAMP:'Championship'
};

// ── Core helpers ───────────────────────────────────────────
function resolveSlot(teamSlot, results) {
  if (teamSlot.type === 'fixed')  return teamSlot.team;
  if (teamSlot.type === 'winner') return results[teamSlot.slot]?.winner || null;
  if (teamSlot.type === 'loser')  return results[teamSlot.slot]?.loser  || null;
  return null;
}

function slotLabel(teamSlot) {
  if (teamSlot.type === 'fixed')  return teamSlot.team;
  const g = GAMES[teamSlot.slot];
  const lbl = g ? g.label : teamSlot.slot;
  if (teamSlot.type === 'winner') return 'Winner of ' + lbl;
  if (teamSlot.type === 'loser')  return 'Loser of '  + lbl;
  return '?';
}

function shortName(name) {
  if (!name) return name;
  return name.trim().split(/\s+/).slice(0,2).join(' ');
}

function smartLabel(teamSlot, results) {
  const resolved = resolveSlot(teamSlot, results);
  if (resolved) return resolved;
  if (teamSlot.type === 'fixed') return teamSlot.team;
  const sourceG = GAMES[teamSlot.slot];
  if (!sourceG) return slotLabel(teamSlot);
  const p1 = resolveSlot(sourceG.t1, results);
  const p2 = resolveSlot(sourceG.t2, results);
  if (p1 && p2) {
    const prefix = teamSlot.type === 'winner' ? 'Winner of' : 'Loser of';
    return prefix + ' ' + shortName(p1) + ' / ' + shortName(p2);
  }
  return slotLabel(teamSlot);
}

// Find which slot's result feeds into a given team slot
function findNextSlot(sid, type) {
  for (const [nsid, ng] of Object.entries(GAMES)) {
    if (ng.t1.type === type && ng.t1.slot === sid) return nsid;
    if (ng.t2.type === type && ng.t2.slot === sid) return nsid;
  }
  return null;
}

function isEliminated(teamName, results) {
  for (const [sid, r] of Object.entries(results)) {
    if (r.loser === teamName) {
      const round = GAMES[sid]?.round;
      if (['QF','SF','CHAMP'].includes(round)) return true;
    }
  }
  let losses = 0;
  for (const r of Object.values(results)) {
    if (r.loser === teamName) losses++;
  }
  return losses >= 2;
}

// Get all occupied slot IDs sorted by round then num
function occupiedSlots() {
  return Object.keys(GAMES).sort((a,b) => {
    const pa = parseSlotId(a), pb = parseSlotId(b);
    const ri = ROUND_ORDER.indexOf(pa.round) - ROUND_ORDER.indexOf(pb.round);
    if (ri !== 0) return ri;
    return (pa.side + pa.num) < (pb.side + pb.num) ? -1 : 1;
  });
}

// Get occupied slots for a given round and side
function slotsForRoundSide(round, side) {
  return Object.keys(GAMES)
    .filter(sid => GAMES[sid].round === round && GAMES[sid].side === side)
    .sort((a,b) => GAMES[a].num - GAMES[b].num);
}

// Apply schedule overrides
function applySchedule(schedule) {
  for (const [sid, overrides] of Object.entries(schedule)) {
    if (!GAMES[sid]) continue;
    if (overrides.time)   GAMES[sid].time  = overrides.time;
    if (overrides.label)  GAMES[sid].label = overrides.label;
    if (overrides.num != null) GAMES[sid].num = parseInt(overrides.num);
    // Team source overrides
    for (const tk of ['t1','t2']) {
      const srcKey  = tk + 'slot';
      const typeKey = tk + 'type';
      const nameKey = tk + 'name';
      if (overrides[nameKey] && GAMES[sid][tk].type === 'fixed') {
        GAMES[sid][tk].team = overrides[nameKey];
      }
      if (overrides[srcKey] || overrides[typeKey]) {
        if (GAMES[sid][tk].type !== 'fixed') {
          if (overrides[srcKey])  GAMES[sid][tk].slot = overrides[srcKey];
          if (overrides[typeKey]) GAMES[sid][tk].type = overrides[typeKey];
        }
      }
    }
  }
}

if (typeof module !== 'undefined') {
  module.exports = {
    GAMES, SLOT_DEFS, ROUND_ORDER, ROUND_LABELS,
    allSlotIds, parseSlotId, occupiedSlots, slotsForRoundSide,
    resolveSlot, slotLabel, smartLabel, shortName,
    isEliminated, findNextSlot, applySchedule
  };
}
