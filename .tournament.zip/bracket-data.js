// bracket-data.js — single source of truth for all bracket logic

const TEAMS = {
  'Wasted Grain':               { side: 'left',  r1game: null },
  'Coors Light':                { side: 'right', r1game: null },
  'High Point Roofing':         { side: 'left',  r1game: 'G1' },
  'Dollys':                     { side: 'left',  r1game: 'G1' },
  'Brew Crew':                  { side: 'left',  r1game: 'G3' },
  'Electric Motor Supply':      { side: 'left',  r1game: 'G3' },
  'Hoegeymeyer Seeds/Feld Fire':{ side: 'left',  r1game: 'G5' },
  'Kerps/Budweiser':            { side: 'left',  r1game: 'G5' },
  'Shreck Bin Co Red':          { side: 'right', r1game: 'G2' },
  'WP Trucking':                { side: 'right', r1game: 'G2' },
  'Michaels Shoes':             { side: 'right', r1game: 'G4' },
  'Wittrock Electric/Weitl Auto':{ side: 'right', r1game: 'G4' },
  'Templeton Distillery':       { side: 'right', r1game: 'G6' },
  'Tropics':                    { side: 'right', r1game: 'G6' },
};

// Game definitions — static slots, participants resolved dynamically
const GAMES = {
  G1:  { label: 'G1',  round: 'R1',      day: 'Sunday',    time: 'Sun 11:30', side: 'left',
         t1: { type: 'fixed', team: 'High Point Roofing' },
         t2: { type: 'fixed', team: 'Dollys' } },
  G2:  { label: 'G2',  round: 'R1',      day: 'Sunday',    time: 'Sun 2:00',  side: 'right',
         t1: { type: 'fixed', team: 'Shreck Bin Co Red' },
         t2: { type: 'fixed', team: 'WP Trucking' } },
  G3:  { label: 'G3',  round: 'R1',      day: 'Sunday',    time: 'Sun 12:20', side: 'left',
         t1: { type: 'fixed', team: 'Brew Crew' },
         t2: { type: 'fixed', team: 'Electric Motor Supply' } },
  G4:  { label: 'G4',  round: 'R1',      day: 'Sunday',    time: 'Sun 2:50',  side: 'right',
         t1: { type: 'fixed', team: 'Michaels Shoes' },
         t2: { type: 'fixed', team: 'Wittrock Electric/Weitl Auto' } },
  G5:  { label: 'G5',  round: 'R1',      day: 'Sunday',    time: 'Sun 1:10',  side: 'left',
         t1: { type: 'fixed', team: 'Hoegeymeyer Seeds/Feld Fire' },
         t2: { type: 'fixed', team: 'Kerps/Budweiser' } },
  G6:  { label: 'G6',  round: 'R1',      day: 'Sunday',    time: 'Sun 3:30',  side: 'right',
         t1: { type: 'fixed', team: 'Templeton Distillery' },
         t2: { type: 'fixed', team: 'Tropics' } },

  G7:  { label: 'G7',  round: 'R2',      day: 'Monday',    time: 'Mon 6:00',  side: 'left',
         t1: { type: 'fixed', team: 'Wasted Grain' },
         t2: { type: 'loser', game: 'G5' } },
  G8:  { label: 'G8',  round: 'R2',      day: 'Monday',    time: 'Mon 6:50',  side: 'right',
         t1: { type: 'fixed', team: 'Coors Light' },
         t2: { type: 'loser', game: 'G6' } },
  G9:  { label: 'G9',  round: 'R2',      day: 'Monday',    time: 'Mon 7:40',  side: 'left',
         t1: { type: 'winner', game: 'G1' },
         t2: { type: 'winner', game: 'G3' } },
  G10: { label: 'G10', round: 'R2',      day: 'Monday',    time: 'Mon 9:20',  side: 'right',
         t1: { type: 'winner', game: 'G2' },
         t2: { type: 'winner', game: 'G4' } },
  G11: { label: 'G11', round: 'R2',      day: 'Wednesday', time: 'Wed 6:30',  side: 'left',
         t1: { type: 'winner', game: 'G5' },
         t2: { type: 'loser',  game: 'G1' } },
  G12: { label: 'G12', round: 'R2',      day: 'Monday',    time: 'Mon 8:30',  side: 'right',
         t1: { type: 'winner', game: 'G6' },
         t2: { type: 'loser',  game: 'G2' } },
  G13: { label: 'G13', round: 'R2',      day: 'Wednesday', time: 'Wed 6:00',  side: 'left',
         t1: { type: 'loser',  game: 'G3' },
         t2: { type: 'loser',  game: 'G8' } },   // G8 loser crosses from right
  G14: { label: 'G14', round: 'R2',      day: 'Wednesday', time: 'Wed 7:40',  side: 'right',
         t1: { type: 'loser',  game: 'G4' },
         t2: { type: 'loser',  game: 'G7' } },   // G7 loser crosses from left

  G15: { label: 'G15', round: 'QF',      day: 'Wednesday', time: 'Wed 9:20',  side: 'left',
         t1: { type: 'winner', game: 'G7' },
         t2: { type: 'winner', game: 'G9' } },
  G16: { label: 'G16', round: 'QF',      day: 'Wednesday', time: 'Wed 8:30',  side: 'right',
         t1: { type: 'winner', game: 'G8' },
         t2: { type: 'winner', game: 'G10' } },
  G17: { label: 'G17', round: 'QF',      day: 'Friday',    time: 'Fri 6:00',  side: 'left',
         t1: { type: 'winner', game: 'G11' },
         t2: { type: 'winner', game: 'G13' } },
  G18: { label: 'G18', round: 'QF',      day: 'Friday',    time: 'Fri 6:50',  side: 'right',
         t1: { type: 'winner', game: 'G12' },
         t2: { type: 'winner', game: 'G14' } },

  G19: { label: 'G19', round: 'SF',      day: 'Friday',    time: 'Fri 7:40',  side: 'left',
         t1: { type: 'winner', game: 'G15' },
         t2: { type: 'winner', game: 'G17' } },
  G20: { label: 'G20', round: 'SF',      day: 'Friday',    time: 'Fri 8:30',  side: 'right',
         t1: { type: 'winner', game: 'G16' },
         t2: { type: 'winner', game: 'G18' } },

  G21: { label: 'G21', round: 'CHAMP',   day: 'Friday',    time: 'Fri 9:20',  side: 'both',
         t1: { type: 'winner', game: 'G19' },
         t2: { type: 'winner', game: 'G20' } },
};

const ROUND_ORDER = ['R1', 'R2', 'QF', 'SF', 'CHAMP'];
const ROUND_LABELS = { R1: 'Round 1', R2: 'Round 2', QF: 'Quarter Finals', SF: 'Semi Finals', CHAMP: 'Championship' };

// Given results, resolve what team fills a slot
function resolveSlot(slot, results) {
  if (slot.type === 'fixed') return slot.team;
  if (slot.type === 'winner') return results[slot.game]?.winner || null;
  if (slot.type === 'loser')  return results[slot.game]?.loser  || null;
  return null;
}

// Resolve both participants of a game
function resolveGame(gameId, results) {
  const g = GAMES[gameId];
  return {
    t1: resolveSlot(g.t1, results),
    t2: resolveSlot(g.t2, results),
  };
}

// Get label for an unresolved slot
function slotLabel(slot) {
  if (slot.type === 'fixed')  return slot.team;
  if (slot.type === 'winner') return `Winner of ${slot.game}`;
  if (slot.type === 'loser')  return `Loser of ${slot.game}`;
  return '?';
}

// Get all games a team could possibly play, and which ones are confirmed
function teamSchedule(teamName, results) {
  const games = [];

  // Find every game where this team is a confirmed participant or possible participant
  for (const [gid, g] of Object.entries(GAMES)) {
    const { t1, t2 } = resolveGame(gid, results);
    const t1Label = slotLabel(g.t1);
    const t2Label = slotLabel(g.t2);

    const confirmed = t1 === teamName || t2 === teamName;
    const possible  = !confirmed && (t1Label === teamName || t2Label === teamName ||
                      t1Label.includes(teamName) || t2Label.includes(teamName));

    if (confirmed) {
      const won  = results[gid]?.winner === teamName;
      const lost = results[gid]?.loser  === teamName;
      games.push({ gid, time: g.time, round: g.round, confirmed: true, won, lost,
                   opponent: t1 === teamName ? (t2 || t2Label) : (t1 || t1Label),
                   result: won ? 'W' : lost ? 'L' : null });
    }
  }

  // Build possible future path for unresolved games
  // Walk forward from last confirmed game
  const paths = buildPaths(teamName, results);

  return { confirmed: games, paths };
}

// Build the win/lose path tree for a team going forward
function buildPaths(teamName, results) {
  // Find the team's current position — last game they appear in as confirmed but unresolved
  const paths = [];

  function walk(gid, label) {
    const g = GAMES[gid];
    const { t1, t2 } = resolveGame(gid, results);
    const alreadyPlayed = results[gid]?.winner != null;

    if (alreadyPlayed) {
      const won = results[gid].winner === teamName;
      // Continue down the won path only
      const nextWin  = findNextGame(gid, 'winner');
      const nextLose = findNextGame(gid, 'loser');
      if (won && nextWin)  walk(nextWin,  'If win');
      if (!won && nextLose) walk(nextLose, 'If lose');
      return;
    }

    // Unplayed — show as possible
    if (t1 === teamName || t2 === teamName) {
      const nextWin  = findNextGame(gid, 'winner');
      const nextLose = findNextGame(gid, 'loser');
      const opp = t1 === teamName ? (t2 || slotLabel(g.t2)) : (t1 || slotLabel(g.t1));

      paths.push({
        gid, time: g.time, round: g.round, label,
        opponent: opp,
        ifWin:  nextWin  ? { gid: nextWin,  time: GAMES[nextWin].time,  round: GAMES[nextWin].round }  : { gid: 'CHAMP_WIN', time: '', round: '' },
        ifLose: nextLose ? { gid: nextLose, time: GAMES[nextLose].time, round: GAMES[nextLose].round } : null,
      });
    }
  }

  // Find entry point — first unplayed game with this team
  for (const gid of Object.keys(GAMES)) {
    const { t1, t2 } = resolveGame(gid, results);
    if ((t1 === teamName || t2 === teamName) && !results[gid]?.winner) {
      paths.push({ gid, time: GAMES[gid].time, round: GAMES[gid].round });
      // Walk win and lose from here
      const g = GAMES[gid];
      const opp = t1 === teamName ? (t2 || slotLabel(g.t2)) : (t1 || slotLabel(g.t1));
      const lastEntry = paths[paths.length - 1];
      lastEntry.opponent = opp;
      lastEntry.ifWin  = (() => { const n = findNextGame(gid, 'winner');  return n ? { gid: n, time: GAMES[n].time, round: GAMES[n].round } : null; })();
      lastEntry.ifLose = (() => { const n = findNextGame(gid, 'loser');   return n ? { gid: n, time: GAMES[n].time, round: GAMES[n].round } : null; })();
      break;
    }
  }

  return paths;
}

// Find which game this game's winner/loser feeds into
function findNextGame(gid, type) {
  for (const [nid, ng] of Object.entries(GAMES)) {
    if (ng.t1.type === type && ng.t1.game === gid) return nid;
    if (ng.t2.type === type && ng.t2.game === gid) return nid;
  }
  return null;
}

// Check if a team is eliminated (has 2 losses or lost a single-elim game)
function isEliminated(teamName, results) {
  let losses = 0;
  for (const [gid, r] of Object.entries(results)) {
    if (r.loser === teamName) losses++;
  }
  // In this format: any team that lost a game after R1 is eliminated (single elim after 2-game guarantee)
  // Simpler: if they lost 2 games, or if they lost in QF/SF/CHAMP (single elim rounds)
  for (const [gid, r] of Object.entries(results)) {
    if (r.loser === teamName) {
      const round = GAMES[gid].round;
      if (['QF', 'SF', 'CHAMP'].includes(round)) return true;
    }
  }
  return losses >= 2;
}

// Export for use in both index.html and admin.html
if (typeof module !== 'undefined') {
  module.exports = { TEAMS, GAMES, ROUND_ORDER, ROUND_LABELS, resolveGame, resolveSlot, slotLabel, teamSchedule, isEliminated, findNextGame };
}
