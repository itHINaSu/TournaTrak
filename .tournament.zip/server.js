const http = require('http');
const fs   = require('fs');
const path = require('path');

const RESULTS_FILE = '/data/results.json';

function readResults() {
  try {
    return JSON.parse(fs.readFileSync(RESULTS_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function writeResults(data) {
  fs.writeFileSync(RESULTS_FILE, JSON.stringify(data, null, 2));
}

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204); res.end(); return;
  }

  const url = req.url.split('?')[0];

  // GET /api/results
  if (req.method === 'GET' && url === '/api/results') {
    const data = readResults();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data));
    return;
  }

  // POST /api/results  { game: "G1", winner: "Team A", loser: "Team B" }
  if (req.method === 'POST' && url === '/api/results') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const { game, winner, loser } = JSON.parse(body);
        if (!game || !winner || !loser) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'game, winner, loser required' }));
          return;
        }
        const data = readResults();
        data[game] = { winner, loser };
        writeResults(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'invalid json' }));
      }
    });
    return;
  }

  // DELETE /api/results/:game  — clear a single result
  if (req.method === 'DELETE' && url.startsWith('/api/results/')) {
    const game = url.split('/').pop().toUpperCase();
    const data = readResults();
    if (data[game]) {
      data[game] = { winner: null, loser: null };
      writeResults(data);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'game not found' }));
    }
    return;
  }

  res.writeHead(404); res.end('not found');
});

server.listen(3000, () => console.log('API listening on :3000'));
